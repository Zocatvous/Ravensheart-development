*------------------------------------------------------*
                   T H E  E N D .
*------------------------------------------------------*

 This is the end, my only friend - the end..
 It took a while to make this font, I should take
 money for it but I dont! Its free.
 I made it for all you Sociopaths out there.
 You remind me of the bitter end.

  ----------------------------------------------------------------------------


  COPYRIGHT LAWS :

  YOU CAN USE THE FONT FOR FREE THINGS (I.E. THINGS THAT YOU DON'T EARN MONEY FROM).
  IF YOU ARE GOING TO USE THE FONT FOR COMMERCIAL THINGS (I.E. THINGS YOU EARN MONEY
  FROM) YOU'LL HAVE TO CONTACT ME ON THESE ADRESSES BECAUSE THERE IS A REGISTRATION/
  LICENSE FEE :

  homerec@undergroundstar.com
  fontex2000mg@softhome.net
  slemhinnor@yahoo.se
  advert@undergroundstar.com


  ------------------------------------------------------------------------------
