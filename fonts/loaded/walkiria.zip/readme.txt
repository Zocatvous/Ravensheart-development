Thank you for get this typography! 

This font was designed remembering the medieval and gothic scriptoriums. 
If you want to donnate or make contact,
please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com

Copyright 2012. David Espinosa Type Foundry. Just for personal use.
