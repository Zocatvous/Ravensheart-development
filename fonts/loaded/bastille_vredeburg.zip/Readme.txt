Hello Everyone :)

Thank for downloading My font.


NOTE:


By installing or using this font, you are agree to the Product Usage Agreement
This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!


Here is the link to purchase full version and commercial license:
https://fontbundles.net/taznix/742149-bastille-vredeburg-vintage-layered-extra
https://www.creativefabrica.com/product/bastille-vredeburg/ 


Any donation are very appreciated. Paypal account for donation : paypal.me/anafauziyah


Thank you
